// File: Sources/ply2splat/KSplatWriter.swift
import Foundation
import simd

/// Writes .ksplat format (mkkellogg/GaussianSplats3D)
///
/// File structure:
/// - Header (4 bytes): magic version u8, section count u32... etc.
/// - Section headers: per-section metadata (bucket info, compression, counts)
/// - Section data: packed splat data per section
///
/// Compression level 0: all floats 32-bit
/// Compression level 1: position/scale/rotation/SH as float16
/// Compression level 2: same as 1 but SH as uint8
///
/// For simplicity, we write a single section with all splats (no spatial bucketing
/// for compression 0, basic center-offset bucketing for 1/2).
final class KSplatWriter {
    let compressionLevel: Int

    init(compressionLevel: Int = 1) {
        self.compressionLevel = min(max(compressionLevel, 0), 2)
    }

    func write(cloud: GaussianCloud, to path: String) throws {
        var buffer = Data()

        // ── KSplat file header ──
        // Version tag: we write version 0 (uncompressed) or version 1 (compressed)
        // Format from GaussianSplats3D SplatBuffer:
        //
        // File header (16 bytes):
        //   [0]  u16: version/magic (0 = uncompressed sections, 1 = compressed)
        //   [2]  u8:  sectionCount
        //   [3]  u8:  splatCount high bits padding
        //   [4]  u32: total splatCount
        //   [8]  u8:  compressionLevel
        //   [9]  u8:  SH degree stored
        //   [10] u8[6]: reserved

        let version: UInt16 = compressionLevel > 0 ? 1 : 0
        let sectionCount: UInt8 = 1
        let splatCount = UInt32(cloud.count)
        let shDeg = UInt8(cloud.shDegree)

        appendU16(&buffer, version)
        buffer.append(sectionCount)
        buffer.append(0) // padding
        appendU32(&buffer, splatCount)
        buffer.append(UInt8(compressionLevel))
        buffer.append(shDeg)
        buffer.append(contentsOf: [UInt8](repeating: 0, count: 6)) // reserved

        // ── Section header (64 bytes) ──
        // For compression 0:
        //   splatCount: u32
        //   maxSplatCount: u32
        //   bucketSize: u32
        //   bucketCount: u32
        //   bucketBlockSize: f32
        //   halfBucketBlockSize: f32
        //   bucketStorageSizeBytes: u32
        //   compressionScaleRange: u32 (0 for uncompressed)
        //   storageSizeBytes: u32
        //   fullBucketCount: u32
        //   partiallyFilledBucketCount: u32
        //   bucketCenter: [f32 x 3]
        //   reserved: padding to 64 bytes

        let bucketSize: UInt32 = 256
        let bucketCount: UInt32 = UInt32((cloud.count + Int(bucketSize) - 1) / Int(bucketSize))
        let blockSize: Float = 5.0

        // Calculate per-splat data sizes
        let bytesPerSplat = splatDataSize(cloud: cloud)
        let totalDataSize = UInt32(cloud.count) * UInt32(bytesPerSplat)

        // Bucket storage: for compressed, each bucket has 12 bytes header (center xyz as f32)
        let bucketStorageSize: UInt32 = compressionLevel > 0 ? bucketCount * 12 : 0

        // Section header
        appendU32(&buffer, splatCount)
        appendU32(&buffer, splatCount)          // maxSplatCount
        appendU32(&buffer, bucketSize)
        appendU32(&buffer, bucketCount)
        appendF32(&buffer, blockSize)
        appendF32(&buffer, blockSize * 0.5)
        appendU32(&buffer, bucketStorageSize)
        appendU32(&buffer, compressionLevel > 0 ? 1 : 0) // compressionScaleRange
        appendU32(&buffer, totalDataSize + bucketStorageSize)
        appendU32(&buffer, bucketCount)         // fullBucketCount (simplified)
        appendU32(&buffer, 0)                   // partiallyFilledBucketCount

        // Scene center (compute bounding box center)
        let center = computeCenter(cloud)
        appendF32(&buffer, center.x)
        appendF32(&buffer, center.y)
        appendF32(&buffer, center.z)

        // Pad to 64 bytes total section header
        let sectionHeaderSoFar = 44 + 12  // 11 u32/f32 fields + 3 f32 center = 56 bytes
        let sectionHeaderPad = 64 - sectionHeaderSoFar
        buffer.append(contentsOf: [UInt8](repeating: 0, count: sectionHeaderPad))

        // ── Bucket headers (for compressed) ──
        if compressionLevel > 0 {
            // Each bucket: center (3 × f32) = 12 bytes
            let splatsPerBucket = Int(bucketSize)
            for bIdx in 0..<Int(bucketCount) {
                let start = bIdx * splatsPerBucket
                let end = min(start + splatsPerBucket, cloud.count)
                let bCenter = bucketCenter(cloud: cloud, start: start, end: end)
                appendF32(&buffer, bCenter.x)
                appendF32(&buffer, bCenter.y)
                appendF32(&buffer, bCenter.z)
            }
        }

        // ── Splat data ──
        switch compressionLevel {
        case 0:
            writeUncompressed(&buffer, cloud: cloud)
        case 1, 2:
            writeCompressed(&buffer, cloud: cloud)
        default:
            writeUncompressed(&buffer, cloud: cloud)
        }

        try buffer.write(to: URL(fileURLWithPath: path))
    }

    // ── Uncompressed (level 0) ──
    // Per splat: position(3×f32) + scale(3×f32) + rotation(4×f32) + color(4×u8) + SH
    private func writeUncompressed(_ buffer: inout Data, cloud: GaussianCloud) {
        for splat in cloud.splats {
            // Position
            appendF32(&buffer, splat.position.x)
            appendF32(&buffer, splat.position.y)
            appendF32(&buffer, splat.position.z)
            // Scale (already exp'd)
            appendF32(&buffer, splat.scale.x)
            appendF32(&buffer, splat.scale.y)
            appendF32(&buffer, splat.scale.z)
            // Rotation (w, x, y, z)
            appendF32(&buffer, splat.rotation.real)
            appendF32(&buffer, splat.rotation.imag.x)
            appendF32(&buffer, splat.rotation.imag.y)
            appendF32(&buffer, splat.rotation.imag.z)
            // Color RGBA
            buffer.append(splat.color.x)
            buffer.append(splat.color.y)
            buffer.append(splat.color.z)
            buffer.append(splat.color.w)
            // SH coefficients (f_dc as 3×f32 + f_rest as Nx f32)
            appendF32(&buffer, splat.shDC.x)
            appendF32(&buffer, splat.shDC.y)
            appendF32(&buffer, splat.shDC.z)
            for coeff in splat.shRest {
                appendF32(&buffer, coeff)
            }
        }
    }

    // ── Compressed (level 1/2) ──
    // Per splat: position(3×f16 offset from bucket center) + scale(3×f16) + rotation(4×f16)
    //            + color(4×u8) + SH (f16 for level1, u8 for level2)
    private func writeCompressed(_ buffer: inout Data, cloud: GaussianCloud) {
        let splatsPerBucket = 256
        let bucketCount = (cloud.count + splatsPerBucket - 1) / splatsPerBucket

        for bIdx in 0..<bucketCount {
            let start = bIdx * splatsPerBucket
            let end = min(start + splatsPerBucket, cloud.count)
            let bCenter = bucketCenter(cloud: cloud, start: start, end: end)

            for i in start..<end {
                let splat = cloud.splats[i]

                // Position as offset from bucket center → float16
                appendF16(&buffer, splat.position.x - bCenter.x)
                appendF16(&buffer, splat.position.y - bCenter.y)
                appendF16(&buffer, splat.position.z - bCenter.z)

                // Scale → float16 (already exp'd, store log for reconstruction)
                appendF16(&buffer, log(max(splat.scale.x, 1e-10)))
                appendF16(&buffer, log(max(splat.scale.y, 1e-10)))
                appendF16(&buffer, log(max(splat.scale.z, 1e-10)))

                // Rotation → float16 (w, x, y, z)
                appendF16(&buffer, splat.rotation.real)
                appendF16(&buffer, splat.rotation.imag.x)
                appendF16(&buffer, splat.rotation.imag.y)
                appendF16(&buffer, splat.rotation.imag.z)

                // Color RGBA
                buffer.append(splat.color.x)
                buffer.append(splat.color.y)
                buffer.append(splat.color.z)
                buffer.append(splat.color.w)

                // SH coefficients
                if compressionLevel == 1 {
                    // float16
                    appendF16(&buffer, splat.shDC.x)
                    appendF16(&buffer, splat.shDC.y)
                    appendF16(&buffer, splat.shDC.z)
                    for coeff in splat.shRest {
                        appendF16(&buffer, coeff)
                    }
                } else {
                    // uint8 (level 2): quantize SH to 0-255 range
                    // DC stored as float16, rest as uint8
                    appendF16(&buffer, splat.shDC.x)
                    appendF16(&buffer, splat.shDC.y)
                    appendF16(&buffer, splat.shDC.z)
                    for coeff in splat.shRest {
                        // Quantize from typical range [-2..2] to [0..255]
                        let normalized = (coeff + 2.0) / 4.0
                        let byte = UInt8(max(0, min(255, normalized * 255.0)))
                        buffer.append(byte)
                    }
                }
            }
        }
    }

    private func splatDataSize(cloud: GaussianCloud) -> Int {
        let shRestCount = cloud.splats.first?.shRest.count ?? 0
        switch compressionLevel {
        case 0:
            // 3f32 pos + 3f32 scale + 4f32 rot + 4u8 color + 3f32 shDC + Nf32 shRest
            return 12 + 12 + 16 + 4 + 12 + shRestCount * 4
        case 1:
            // 3f16 pos + 3f16 scale + 4f16 rot + 4u8 color + 3f16 shDC + Nf16 shRest
            return 6 + 6 + 8 + 4 + 6 + shRestCount * 2
        case 2:
            // 3f16 pos + 3f16 scale + 4f16 rot + 4u8 color + 3f16 shDC + Nu8 shRest
            return 6 + 6 + 8 + 4 + 6 + shRestCount * 1
        default:
            return 44
        }
    }

    private func computeCenter(_ cloud: GaussianCloud) -> SIMD3<Float> {
        var minP = SIMD3<Float>(repeating: Float.greatestFiniteMagnitude)
        var maxP = SIMD3<Float>(repeating: -Float.greatestFiniteMagnitude)
        for s in cloud.splats {
            minP = simd_min(minP, s.position)
            maxP = simd_max(maxP, s.position)
        }
        return (minP + maxP) * 0.5
    }

    private func bucketCenter(cloud: GaussianCloud, start: Int, end: Int) -> SIMD3<Float> {
        var sum = SIMD3<Float>(repeating: 0)
        let count = end - start
        for i in start..<end {
            sum += cloud.splats[i].position
        }
        return count > 0 ? sum / Float(count) : SIMD3(repeating: 0)
    }

    // ── Binary helpers ──
    private func appendU16(_ data: inout Data, _ v: UInt16) {
        var val = v; data.append(contentsOf: withUnsafeBytes(of: &val) { Array($0) })
    }
    private func appendU32(_ data: inout Data, _ v: UInt32) {
        var val = v; data.append(contentsOf: withUnsafeBytes(of: &val) { Array($0) })
    }
    private func appendF32(_ data: inout Data, _ v: Float) {
        var val = v; data.append(contentsOf: withUnsafeBytes(of: &val) { Array($0) })
    }
    private func appendF16(_ data: inout Data, _ v: Float) {
        // Convert float32 → float16 (IEEE 754)
        let bits = floatToHalf(v)
        var val = bits; data.append(contentsOf: withUnsafeBytes(of: &val) { Array($0) })
    }

    private func floatToHalf(_ value: Float) -> UInt16 {
        let bits = value.bitPattern
        let sign = (bits >> 31) & 1
        let exponent = Int((bits >> 23) & 0xFF) - 127
        let mantissa = bits & 0x7FFFFF

        if exponent > 15 {
            // Overflow → infinity
            return UInt16(sign << 15) | 0x7C00
        } else if exponent < -14 {
            // Underflow → zero or denorm
            if exponent < -24 { return UInt16(sign << 15) }
            let shift = -14 - exponent
            let m = (mantissa | 0x800000) >> (shift + 13)
            return UInt16(sign << 15) | UInt16(m)
        } else {
            let e = UInt16(exponent + 15)
            let m = UInt16(mantissa >> 13)
            return UInt16(sign << 15) | (e << 10) | m
        }
    }
}
