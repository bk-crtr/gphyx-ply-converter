// File: Sources/ply2splat/main.swift
import Foundation

// ─── CLI ─────────────────────────────────────────────────────
let version = "1.0.0"

func printUsage() {
    let usage = """
    ply2splat v\(version) — Gaussian Splat PLY converter (Metal-accelerated)
    
    USAGE:
      ply2splat <input.ply> [options]
    
    OUTPUT FORMATS (at least one required):
      --splat <output.splat>       antimatter15 format (32 bytes/splat, no SH)
      --ksplat <output.ksplat>     mkkellogg format (compression 0|1|2)
      --spz <output.spz>           Niantic SPZ format (~10x smaller)
      --all <basename>             Export all three: basename.splat, .ksplat, .spz
    
    OPTIONS:
      --sh-degree <0|1|2|3>        Max SH degree to preserve (default: auto from PLY)
      --compression <0|1|2>        KSPLAT compression level (default: 1)
      --alpha-threshold <0-255>    Remove splats with alpha below this (default: 1)
      --no-metal                   Disable Metal, use CPU fallback
      --verbose                    Print detailed progress
      --help                       Show this help
    
    EXAMPLES:
      ply2splat scene.ply --all scene
      ply2splat scene.ply --splat scene.splat --spz scene.spz
      ply2splat scene.ply --ksplat scene.ksplat --compression 2 --sh-degree 1
    
    © GPHYX 2025
    """
    print(usage)
}

// ─── Parse arguments ─────────────────────────────────────────
var args = CommandLine.arguments.dropFirst().makeIterator()
var inputPath: String?
var splatOutput: String?
var ksplatOutput: String?
var spzOutput: String?
var maxSHDegree: Int = -1  // -1 = auto
var compressionLevel: Int = 1
var alphaThreshold: Int = 1
var useMetal: Bool = true
var verbose: Bool = false

while let arg = args.next() {
    switch arg {
    case "--help", "-h":
        printUsage()
        exit(0)
    case "--splat":
        guard let val = args.next() else { fputs("Error: --splat requires path\n", stderr); exit(1) }
        splatOutput = val
    case "--ksplat":
        guard let val = args.next() else { fputs("Error: --ksplat requires path\n", stderr); exit(1) }
        ksplatOutput = val
    case "--spz":
        guard let val = args.next() else { fputs("Error: --spz requires path\n", stderr); exit(1) }
        spzOutput = val
    case "--all":
        guard let val = args.next() else { fputs("Error: --all requires basename\n", stderr); exit(1) }
        splatOutput = val + ".splat"
        ksplatOutput = val + ".ksplat"
        spzOutput = val + ".spz"
    case "--sh-degree":
        guard let val = args.next(), let v = Int(val), (0...3).contains(v) else {
            fputs("Error: --sh-degree requires 0-3\n", stderr); exit(1)
        }
        maxSHDegree = v
    case "--compression":
        guard let val = args.next(), let v = Int(val), (0...2).contains(v) else {
            fputs("Error: --compression requires 0-2\n", stderr); exit(1)
        }
        compressionLevel = v
    case "--alpha-threshold":
        guard let val = args.next(), let v = Int(val), (0...255).contains(v) else {
            fputs("Error: --alpha-threshold requires 0-255\n", stderr); exit(1)
        }
        alphaThreshold = v
    case "--no-metal":
        useMetal = false
    case "--verbose":
        verbose = true
    default:
        if arg.hasPrefix("-") {
            fputs("Unknown option: \(arg)\n", stderr); exit(1)
        }
        inputPath = arg
    }
}

guard let input = inputPath else {
    fputs("Error: no input PLY file specified\n", stderr)
    printUsage()
    exit(1)
}

if splatOutput == nil && ksplatOutput == nil && spzOutput == nil {
    fputs("Error: no output format specified (use --splat, --ksplat, --spz, or --all)\n", stderr)
    printUsage()
    exit(1)
}

// ─── Run ─────────────────────────────────────────────────────
func log(_ msg: String) {
    if verbose { print("[ply2splat] \(msg)") }
}

do {
    let startTime = CFAbsoluteTimeGetCurrent()

    // 1. Parse PLY
    log("Parsing PLY: \(input)")
    let plyData = try Data(contentsOf: URL(fileURLWithPath: input))
    let parser = PLYParser()
    var cloud = try parser.parse(data: plyData)
    log("Parsed \(cloud.count) splats, SH degree \(cloud.shDegree)")

    // 2. Apply SH degree cap
    if maxSHDegree >= 0 && maxSHDegree < cloud.shDegree {
        cloud.capSHDegree(to: maxSHDegree)
        log("Capped SH degree to \(maxSHDegree)")
    }

    // 3. Transform on Metal (sigmoid, exp(scale), normalize quaternion, SH→RGB)
    if useMetal {
        log("Running Metal compute transforms...")
        let transformer = try MetalTransformer()
        try transformer.transform(&cloud)
        log("Metal transform complete")
    } else {
        log("CPU transform...")
        cloud.transformCPU()
        log("CPU transform complete")
    }

    // 4. Filter by alpha
    if alphaThreshold > 0 {
        let before = cloud.count
        cloud.filterByAlpha(minAlpha: UInt8(alphaThreshold))
        log("Filtered \(before - cloud.count) splats below alpha \(alphaThreshold), \(cloud.count) remaining")
    }

    // 5. Export
    if let path = splatOutput {
        log("Writing .splat → \(path)")
        let writer = SplatWriter()
        try writer.write(cloud: cloud, to: path)
        let size = try FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64 ?? 0
        log(".splat written: \(formatBytes(size))")
    }

    if let path = ksplatOutput {
        log("Writing .ksplat → \(path) (compression: \(compressionLevel))")
        let writer = KSplatWriter(compressionLevel: compressionLevel)
        try writer.write(cloud: cloud, to: path)
        let size = try FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64 ?? 0
        log(".ksplat written: \(formatBytes(size))")
    }

    if let path = spzOutput {
        log("Writing .spz → \(path)")
        let writer = SPZWriter()
        try writer.write(cloud: cloud, to: path)
        let size = try FileManager.default.attributesOfItem(atPath: path)[.size] as? UInt64 ?? 0
        log(".spz written: \(formatBytes(size))")
    }

    let elapsed = CFAbsoluteTimeGetCurrent() - startTime
    let inputSize = try FileManager.default.attributesOfItem(atPath: input)[.size] as? UInt64 ?? 0

    print("✓ Converted \(cloud.count) splats in \(String(format: "%.2f", elapsed))s")
    print("  Input:  \(formatBytes(inputSize))")
    if let p = splatOutput {
        let s = try FileManager.default.attributesOfItem(atPath: p)[.size] as? UInt64 ?? 0
        print("  .splat: \(formatBytes(s))")
    }
    if let p = ksplatOutput {
        let s = try FileManager.default.attributesOfItem(atPath: p)[.size] as? UInt64 ?? 0
        print("  .ksplat:\(formatBytes(s))")
    }
    if let p = spzOutput {
        let s = try FileManager.default.attributesOfItem(atPath: p)[.size] as? UInt64 ?? 0
        print("  .spz:   \(formatBytes(s))")
    }

} catch {
    fputs("Error: \(error.localizedDescription)\n", stderr)
    exit(1)
}

func formatBytes(_ bytes: UInt64) -> String {
    if bytes < 1024 { return "\(bytes) B" }
    if bytes < 1024 * 1024 { return String(format: "%.1f KB", Double(bytes) / 1024) }
    return String(format: "%.1f MB", Double(bytes) / (1024 * 1024))
}
